import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// import { TableComponent } from './components/table/table.component';
import { HeaderComponent } from './components/header/header.component';
import { DellIconComponent } from './components/dell-icon/dell-icon.component';
import { ToggleButtonComponent } from './components/toggle-button/toggle-button.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { NavItemComponent } from './components/navbar/nav-item/nav-item.component';
import { AnalyticsSearchComponent } from './views/analytics-search/analytics-search.component';
import { HomeComponent } from './views/home/home.component';
import { TableComponent } from './components/table/table.component';
import { TableHeaderComponent } from './components/table/table-header/table-header.component';
import { TableBodyComponent } from './components/table/table-body/table-body.component';
import { TableItemComponent } from './components/table/table-item/table-item.component';
import { BtnSearchComponent } from './components/btn-search/btn-search.component';
import { BtnSelectFilterComponent } from './components/btn-select-filter/btn-select-filter.component';
import { InputComponent } from './components/input/input.component';
import { BtnAddFilterComponent } from './components/btn-add-filter/btn-add-filter.component';
import { BtnOptionsComponent } from './components/btn-options/btn-options.component';
import { SelectComponent } from './components/select/select.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';


@NgModule({
  declarations: [
    HeaderComponent,
    DellIconComponent,
    ToggleButtonComponent,
    NavbarComponent,
    NavItemComponent,
    AnalyticsSearchComponent,
    HomeComponent,
    TableComponent,
    TableHeaderComponent,
    TableBodyComponent,
    TableItemComponent,
    BtnSearchComponent,
    BtnSelectFilterComponent,
    InputComponent,
    BtnAddFilterComponent,
    BtnOptionsComponent,
    SelectComponent
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  exports: [
    HeaderComponent,
    DellIconComponent,
    ToggleButtonComponent,
    NavbarComponent,
    NavItemComponent
  ]
})

export class SharedModule {

}
