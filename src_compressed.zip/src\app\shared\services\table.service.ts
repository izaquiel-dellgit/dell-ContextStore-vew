import { Injectable, EventEmitter } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { SearchService } from './search.service'

@Injectable({
  providedIn: 'root'
})
export class TableService {

  tableResults: any[] = [];

  constructor(private searchService: SearchService) {
    this.waitSearch().asObservable().subscribe((res:any)=> {
//       this.tableResults.push(res);
      this.searchService.getSearchResult(this.tableResults).subscribe((res:any)=>{
        this.tableResults = []
      })
      this.tableResults = []
    })


  }

  subjectSearch = new Subject<any>();
  getData: EventEmitter<any>= new EventEmitter<any>();

  subjectFilter = new Subject<any>();
  subjectValue = new Subject<any>();

  sendMessageFilter(filter: string) {
    this.subjectFilter.next(filter)
  }
  sendMessageValue(value: string) {
    this.subjectValue.next(value)
  }

  receivedMessageFilter(): Observable<string> {
    return this.subjectFilter.asObservable()
  }
  receivedMessageValue(): Observable<any> {
    return this.subjectValue.asObservable()
  }

  waitSearch(): Subject<any>{
    return this.subjectSearch;
  }

  canSubmit(): EventEmitter<any>{
    return this.getData;
  }

}
