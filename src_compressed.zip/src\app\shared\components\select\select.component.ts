import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit, OnChanges {

  
  @Input()
  objects: any;

  @Input()
  attribute: string = "";

  @Input()
  placeholder: string = "";

  @Input()
  label: string | undefined;

  @Input()
  multi: boolean = false;

  @Input()
  selectAll: boolean = false;

  @Input()
  itemsShowLimit: number = 4

  selectedItems: any[];

  @Output()
  selected: EventEmitter<string> = new EventEmitter<string>();

  @Output()
  selecteds: EventEmitter<string[]> = new EventEmitter<string[]>();

  dropdownList: any[];

  
  dropdownSettings: IDropdownSettings = {};
  dropDownForm!: FormGroup;

  constructor(private fb: FormBuilder, private tableService : TableService) {
    this.dropdownList = [];
    this.selectedItems = [];
  }

  ngOnInit() {
    this.buildDropdownList()
    this.selecteds.emit(this.selectedItems);
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.buildDropdownList()
    this.selecteds.emit(this.selectedItems);
  }

  buildDropdownList(){
    if(this.objects){
      this.dropdownList = Array.from(this.objects).map((value, index) => ({ item_id: index, item_name: value }));
    }
    
    this.dropdownSettings = {
      singleSelection: !this.multi,
      idField: 'item_id',
      textField: 'item_name',
      itemsShowLimit: this.itemsShowLimit,
      enableCheckAll: this.multi,
      closeDropDownOnSelection: !this.multi
    };
    if(this.selectAll){
      this.selectedItems = [...this.dropdownList]
      this.dropDownForm = this.fb.group({
        myItems: [this.selectedItems]
      });
    } else {
      this.dropDownForm = this.fb.group({
        myItems: [this.selectedItems]
      });
    }
   
    if(this.selectAll){
      this.selectedItems = [...this.dropdownList];
    }
  }


  onSelectedItems(item: any) {
    this.filterSelectedItems(item);
    this.selectedItems.push(item);
    this.selecteds.emit(this.selectedItems);
  }



  onDeSelectedItems(item: any) {
    this.filterSelectedItems(item);
    this.selecteds.emit(this.selectedItems);
  }

  filterSelectedItems(item: any) {
    this.selectedItems = this.selectedItems.filter(x => x.item_name !== item);
  }

  onSelectAll() {
    this.selectedItems = [...this.dropdownList];
    this.selecteds.emit(this.dropdownList);
  }

  onDeSelectAll() {
    this.selectedItems = [];
    this.selecteds.emit([]);
  }

  onSelectedItem(item: any) {

    this.selectedItems.push(item);
    this.tableService.sendMessageFilter(item.item_name)
    // console.log(JSON.stringify(item))
    this.selected.emit(item);
    // this.filterSelectedItems(item)
  }


  onDeSelectedItem(item: any) {
    this.filterSelectedItems(item);
  }

}
