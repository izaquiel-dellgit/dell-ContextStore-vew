import { Component, OnInit } from '@angular/core';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'app-btn-add-filter',
  templateUrl: './btn-add-filter.component.html',
  styleUrls: ['./btn-add-filter.component.scss']
})
export class BtnAddFilterComponent implements OnInit {


  title  ="Add filter"
  action =""
  
  constructor(private tableService : TableService) { }

  ngOnInit(): void {
   
  }

  sendAction(){
    this.tableService.sendMessageValue(this.action)
   
  }



}
