import { Component, OnInit } from '@angular/core';

export enum OrderKind {
  ASCENDING,DESCENDING,UNORDERED
}
export type TableHeader = {
  value:string,
  label:string,
  // order:OrderKind | undefined
}

@Component({
  selector: 'app-table-header',
  templateUrl: './table-header.component.html',
  styleUrls: ['./table-header.component.scss']
})
export class TableHeaderComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

  headers:TableHeader[] = [
    {value:"Object",label:"Filter Name"},// order:OrderKind.UNORDERED},
    {value:"value",label:"Value"}, //,order:OrderKind.UNORDERED},
    {value:"sort",label:"Sort"}, //,order:OrderKind.UNORDERED},
    {value:"group",label:"Group"}, //,order:OrderKind.UNORDERED},
    {value:"options",label:"Options"}, //,order:OrderKind.UNORDERED},
    {value:"actions",label:"Actions"}, //,order:OrderKind.UNORDERED},
  ]

}
