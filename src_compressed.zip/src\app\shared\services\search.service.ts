import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  url = API_URL + "?query="

  constructor(private http: HttpClient) {}

  getSearchResult(params:any){
    let agg: string = '';
    for(let p of params){
      this.url += p.filter + ':' + p.value + ',';
      if (params.group && params.groupCriteria){ agg += "&agg=" + p.filter + ':' +p.groupCriteria.toLowerCase()}
    }

    this.url = this.url.slice(0, -1)
    this.url += agg;

    console.log("URL:")
    console.log(this.url)
    return this.http.get(this.url);
  }
}
