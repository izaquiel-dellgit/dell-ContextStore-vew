import { AfterViewInit, Component, OnInit, OnChanges, Input } from '@angular/core';
import { TableService } from 'src/app/shared/services/table.service';

@Component({
  selector: 'app-table-body',
  templateUrl: './table-body.component.html',
  styleUrls: ['./table-body.component.scss']
})
export class TableBodyComponent implements OnInit {

  newFilterItem: string = "";
  newValueItem: string = "";

  @Input()
  options: any[] = []

  items: Array<any> = [
    { filter: "filter1", value: "value1" },
    { filter: "filter2", value: "value2" },
//     { filter: "filter3", value: "value3" },
//     { filter: "filter4", value: "value4" },
  ];
  constructor(private tableService: TableService) {
    this.options = ["SUM", "COUNT", "HIGHLIGHT", "AVG", "SUMMARIZE"];
   }

  ngOnInit(): void {
  }

  ngDoCheck(): void {
//     console.log(this.newValueItem, this.newFilterItem)
    this.tableService.receivedMessageValue().subscribe(data => this.newValueItem = data)
    this.tableService.receivedMessageFilter().subscribe(data => this.newFilterItem = data)
  }

  ngAfterViewInit(){
  }

  deleteLine(filter : any): void {
   this.items = this.items.filter(i => i.value != filter);
  }

 addLine(): void {
    const element = { filter: this.newFilterItem, value: this.newValueItem }
    if (element.value && element.filter != "") {
      this.items.push(element)
    } else {
      return
    }
  }
}



