import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalyticsSearchComponent } from './shared/views/analytics-search/analytics-search.component';
import { HomeComponent } from './shared/views/home/home.component';

const routes: Routes = [
  {path: 'analyticsSearch' , component: AnalyticsSearchComponent},
  {path: 'home' , component: HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
