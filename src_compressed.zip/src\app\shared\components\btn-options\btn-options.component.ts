import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-options',
  templateUrl: './btn-options.component.html',
  styleUrls: ['./btn-options.component.scss']
})
export class BtnOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
