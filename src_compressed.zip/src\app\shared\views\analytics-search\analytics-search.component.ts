import { Component, OnInit, Output } from '@angular/core';
import { SearchService } from '../../services/search.service'

@Component({
  selector: 'app-analytics-search',
  templateUrl: './analytics-search.component.html',
  styleUrls: ['./analytics-search.component.scss']
})
export class AnalyticsSearchComponent implements OnInit {

  @Output()
  response: string | any = "";

  mockedData: any = {"contact_region": "BR",
                     "transfer_reason": "Sales"};

  constructor(private searchService: SearchService) { }

  ngOnInit(): void {
//     this.searchService.getSearchResult(this.mockedData).subscribe(res => {this.response= res});
  }

}
