import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SelectComponent } from './select.component';

describe('SelectComponent', () => {
  let component: SelectComponent;
  let fixture: ComponentFixture<SelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SelectComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [FormBuilder]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectComponent);
    component = fixture.componentInstance;
    component.dropDownForm  = new FormGroup({
      myItems: new FormControl()
    }); 
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });

  it('should ngOnChange', () => {
    expect(component.ngOnChanges({})).toBe(void 0)
  });

  it('should buildDropdownList', () => {
    component.objects = ['Types']
    component.selectAll = true
    expect(component.buildDropdownList()).toBe(void 0);
  });

  it('should onSelectedItems', () => {
    const mockedItem = {item_id:'0'}
    component.selectedItems = [{item_id:'0'}]
    expect(component.onSelectedItems(mockedItem)).toBe(void 0)
  });

  it('should onDeSelectedItems', () => {
    const mockedItem = {item_id:'0'}
    expect(component.onDeSelectedItems(mockedItem)).toBe(void 0);
  });

  it('should onSelectAll', () => {
    expect(component.onSelectAll()).toBe(void 0);
  });

  it('should onDeSelectAll', () => {
    expect(component.onDeSelectAll()).toBe(void 0);
  });

  it('should onSelectedItem', () => {
    const mockedItem = {item_id:'0'}
    expect(component.onSelectedItem(mockedItem)).toBe(void 0);
  });

  it('should onDeSelectedItem', () => {
    const mockedItem = {item_id:'0'}
    expect(component.onDeSelectedItem(mockedItem)).toBe(void 0);
  });
});
