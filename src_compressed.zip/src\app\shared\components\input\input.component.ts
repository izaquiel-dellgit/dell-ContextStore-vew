import { Component, OnInit } from '@angular/core';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {

  value: string = "";

  constructor(private tableService: TableService) {

  }

  sendValue(): void {
    this.tableService.sendMessageValue(this.value)
  }

  ngDoCheck(): void {
    this.sendValue()
  }

  cleanValue(): void {
    this.value = ""
  }

  ngOnInit(): void {
  }

}
