export const API_URL = 'https://dcis-redix.r1.pcf.dell.com/data/retrieve/aggregate';
