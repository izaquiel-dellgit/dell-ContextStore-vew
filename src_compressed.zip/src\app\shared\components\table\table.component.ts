import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, EventEmitter } from '@angular/core';
import { API_URL } from '../../../shared/constants';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit, AfterViewInit {

  all_params: any[];
  params: any = {};
  group: string | undefined;

  @ViewChild('select') select!: any;
  @ViewChild('tableBody') tableBody!: any
  @ViewChild('inputField') inputField!: any

  filterSelected: string = ""

  constructor(private tableService: TableService) {

    this.all_params = ["contact_region", "transfer_reason", "product_line"];
    var url = this.getURL();
    console.log(url)
  }

  ngDoCheck(): void {
    this.tableService.receivedMessageFilter().subscribe(data => this.filterSelected = data)
  }

  ngAfterViewInit(): void {
  }

  ngOnInit(): void {
  }

  addParam(param: string, value: string): void {
    if (this.all_params.indexOf(param) != -1) {
      this.params[param] = value;
      this.all_params.splice(this.all_params.indexOf(param), 1)
    }
  }

  getURL(): string {
    var url = API_URL + "?query=";
    for (var c in this.params) {
      url += c + ':' + this.params[c] + ',';
    }
    url = url.slice(0, -1) + "&agg=product_line:count"
    return url;
  }

  selectedObjects(event: any): void {

  }

  deleteFilter(filter: string): void {
    this.all_params = this.all_params.filter(i => i.filter != filter)
  }

  addNewFilter(newFilter: string): void {
    this.all_params.push(newFilter)
  }
  removeFilter():void{
    this.all_params = this.select
  }


  ClickEvent(): void {
    this.tableBody.addLine()
    this.inputField.cleanValue()
    console.log(this.select.onDeSelectedItem(this.filterSelected))
    
   // this.removeFilter()

  }

  onSearch(){
    console.log("search Clicked");
    this.tableService.canSubmit().emit({});
  }

}
