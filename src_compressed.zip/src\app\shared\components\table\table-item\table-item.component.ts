import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { TableService } from '../../../services/table.service'


@Component({
  selector: 'app-table-item',
  templateUrl: './table-item.component.html',
  styleUrls: ['./table-item.component.scss']
})
export class TableItemComponent implements OnInit {

  sortChecked: boolean = false;
  groupChecked: boolean = false;

  @Input()
  filter: string = "";
  @Input()
  value: string = "";

  @Input()
  options: any[] = [];

  @Input()
  groupCriteria: string | undefined;

  @Output()
  deleteEvent: EventEmitter<string> = new EventEmitter<string>();

  deleteItem(){
    this.deleteEvent.emit(this.value)
  }

  constructor(private tableService:TableService) {
  }

  ngOnInit(): void {
    this.tableService.canSubmit().subscribe((res:any) =>{
      this.tableService.tableResults.push(this.initParams());
      this.tableService.waitSearch().next(null);
    })
  }

  toggleSort(filter: string): void{
    this.sortChecked = !this.sortChecked;
  }

  toggleGroup(filter: string): void{
    this.groupChecked = !this.groupChecked;
    }

  setCriteria(event: any){
    this.groupCriteria = event.item_name;
  }

  initParams(): any{
    const c : any = {
      "filter" : this.filter,
      "value" : this.value
    }
    if (this.sortChecked) {c.sort = true}
    if (this.groupChecked && this.groupCriteria) {c.group = true; c.groupCriteria = this.groupCriteria}

    return c;
  }
}



