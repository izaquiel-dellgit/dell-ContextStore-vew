import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-select-filter',
  templateUrl: './btn-select-filter.component.html',
  styleUrls: ['./btn-select-filter.component.scss']
})
export class BtnSelectFilterComponent implements OnInit {
  title = "Select filter"

  menuVisible: boolean = false;
  constructor() { }

  ngOnInit(): void {
  }
  toggleShowMenu(): void {
this.menuVisible = !this.menuVisible
  }
}
