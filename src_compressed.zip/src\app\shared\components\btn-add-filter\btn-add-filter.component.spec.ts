import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnAddFilterComponent } from './btn-add-filter.component';

describe('BtnAddFilterComponent', () => {
  let component: BtnAddFilterComponent;
  let fixture: ComponentFixture<BtnAddFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BtnAddFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnAddFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
