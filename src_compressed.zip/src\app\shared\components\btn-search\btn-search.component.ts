import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-search',
  templateUrl: './btn-search.component.html',
  styleUrls: ['./btn-search.component.scss']
})
export class BtnSearchComponent implements OnInit {
  title ="Search"

  constructor() { }

  ngOnInit(): void {
  }

}
