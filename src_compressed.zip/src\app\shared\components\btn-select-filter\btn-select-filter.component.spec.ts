import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnSelectFilterComponent } from './btn-select-filter.component';

describe('BtnSelectFilterComponent', () => {
  let component: BtnSelectFilterComponent;
  let fixture: ComponentFixture<BtnSelectFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BtnSelectFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnSelectFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
